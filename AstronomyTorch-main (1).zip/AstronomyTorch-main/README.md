# AstronomyTorch
A simple Torch which change between to colors
